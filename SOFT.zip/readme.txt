
TIPS: 
https://www.youtube.com/watch?v=qQ1ZBHmqnjY
https://www.youtube.com/watch?v=_Chvj8uVMrw

pass: wpbrutetips